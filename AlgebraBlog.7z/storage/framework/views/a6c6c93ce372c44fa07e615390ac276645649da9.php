<?php $__env->startSection('content'); ?>
    <div class="card" style="width: 18rem;">
        <img class="card-img-top" src="" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($user->name); ?></h5>
            <p class="card-text">Email: <?php echo e($user->email); ?></p>
            <p class="card-text">Kreiran: <?php echo e($user->created_at); ?></p>

            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Nazad</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/users/show.blade.php ENDPATH**/ ?>