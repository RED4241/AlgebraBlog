<?php $__env->startSection('content'); ?>

<div class="card">
        <div class="card-header">Kreiraj korisnika</div>
        <div class="card-body">

            <form method="POST" action="<?php echo e(route('users.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Ime</label>
                <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="Upišite svoje ime">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Upišite svoj e-mail">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" id="password" name="password" placeholder="Upišite svoju lozinku">
                </div>

                <div class="form-group">
                    <label for="password_confirmation">Ponovljeni Password</label>
                    <input type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" id="password_confirmation" name="password_confirmation" placeholder="ponovite svoju lozinku">
                </div>

                <div class="form-group">
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-warning">Nazad</a>
                    <button type="submit" class="btn btn-success float-right">Kreiraj</button>
                </div>  
                
                <?php if($errors->any()): ?>                    
                
                <div class="form-group">
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php echo e($error); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>  
                </div> 

                <?php endif; ?>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/users/create.blade.php ENDPATH**/ ?>