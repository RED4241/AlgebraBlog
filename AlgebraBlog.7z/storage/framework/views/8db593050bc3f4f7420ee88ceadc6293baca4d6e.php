<?php $__env->startSection('content'); ?>

<div class="blog-post">
        <h2 class="blog-post-title">
        
        <a>
        <?php echo e($post->title); ?> Post
        </a>
        </h2>
        <p class="blog-post-meta"><?php echo e($post->created_at->toFormattedDateString()); ?> by <a href="#">Mark</a></p>       
        <article class="text-justify"><?php echo e($post->body); ?></article>     
    </div><!-- /.blog-post -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/posts/show.blade.php ENDPATH**/ ?>