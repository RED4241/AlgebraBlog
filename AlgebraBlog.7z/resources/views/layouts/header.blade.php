<div class="blog-header">
      <div class="container">
        <h1 class="blog-title">{{ config('app.name') }}</h1>
        <p class="lead blog-description">An example blog template built with Bootstrap.</p>
      </div>
    </div>