<?php $__env->startSection('content'); ?>

    <div class="mb-4">
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Kreiraj novog korisnika</a>
    </div>
    
    <?php if($users->count()): ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Created at</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($user->id); ?></th>
                <td><a href="<?php echo e(route('users.show', $user->id)); ?>"><?php echo e($user->name); ?></a></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->created_at); ?></td>
                <td>
                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-sm btn-primary">Uredi</a>
                        <button class="btn btn-sm btn-danger">Obriši</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/users/index.blade.php ENDPATH**/ ?>