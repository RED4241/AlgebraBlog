<?php $__env->startSection('content'); ?>

<div>
    <div>
        <h3>Kreiraj novu objavu</h3>
    </div>
    <hr>
    <div>
        <form action="<?php echo e(route('posts.store')); ?>" method="POST">

            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="title">Naslov</label>
                <input type="text" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" id="title" name="title" value="<?php echo e(old('title')); ?>">
            </div>
            <div class="form-group">
                <label for="body">Post</label>
                <textarea class="form-control <?php echo e($errors->has('body') ? 'is-invalid' : ''); ?>" id="body" name="body"  id="body" cols="80" rows="10"><?php echo e(old('body')); ?></textarea>
            </div>
            <div class="form-group">
                <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-warning">Nazad</a>
                <button type="submit" class="btn btn-success float-right">Kreiraj</button>
            </div>

            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/posts/create.blade.php ENDPATH**/ ?>