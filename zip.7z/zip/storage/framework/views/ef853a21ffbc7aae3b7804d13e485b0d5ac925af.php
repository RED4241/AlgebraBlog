<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-post">
                    <h2 class="blog-post-title">
                        <a href="<?php echo e(route('posts.show', $post->slug)); ?>">
                        <?php echo e($post->title); ?>

                        </a>
                    </h2>
                    <p class="blog-post-meta">
                        <!-- https://carbon.nesbot.com/docs/#api-formatting -->
                        <?php echo e($post->created_at->toFormattedDateString()); ?> by <a href="#"><?php echo e($post->user->name); ?></a>
                    </p>
                    <article class="text-justify">
                        <?php echo e($post->body); ?>

                    </article>
        </div><!-- /.blog-post -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <nav class="blog-pagination">
        <a class="btn btn-outline-primary" href="#">Older</a>
        <a class="btn btn-outline-secondary disabled" href="#">Newer</a>
    </nav>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/posts/index.blade.php ENDPATH**/ ?>