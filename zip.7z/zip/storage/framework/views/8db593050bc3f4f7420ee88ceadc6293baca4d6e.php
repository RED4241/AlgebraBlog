<?php $__env->startSection('content'); ?>

<div class="blog-post">

    <h2 class="blog-post-title">
        <?php echo e($post->title); ?>

    </h2>

    <p class="blog-post-meta">
        <!-- https://carbon.nesbot.com/docs/#api-formatting -->
        <?php echo e($post->created_at->toFormattedDateString()); ?> by<a href="#"><?php echo e($post->user->name); ?></a>
    </p>
    
    <article class="text-justify">
        <?php echo e($post->body); ?>

    </article>

</div>

<form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?> 

        <?php if($post->user_id === auth()->id()): ?>
        <div class="float-right">
            <a href="<?php echo e(route('posts.edit', $post->slug)); ?>" class="btn btn-info">Uredi</a>
            <button class="btn btn-danger">Obriši</button>
         </div>
         <?php endif; ?>

<a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary">Natrag</a>
</form>

<br>

<div class="card">
    <div class="card-body">
        <form action="posts/<?php echo e($post->slug); ?>/comments" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <textarea name="body" id="body" cols="30" rows="3" class="form-control <?php echo e($errors->has('body') ? 'is-invalid' : ''); ?>"></textarea>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Komentiraj</button>
            </div>
        </form>    
    </div>
</div>
<?php if(count($post->comments)): ?>
<br>

<div class="comments">
    <h4>Komentari:</h4>
    <ul class="list-group">
    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
            <b>Ime Prezime</b>
            <i>19.07.2019.</i>
            <p>Ovo je tijelo komentara.</p>
        </li>
        <li class="list-group-item">
            <b><?php echo e($comment->user->name); ?></b>
            <i><?php echo e($comment->created_at->diffForHumans); ?></i>
            <p><?php echo e($comment->body); ?></p>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php else: ?>
<br>
<h4>Budi prvi koji će komentirati ovaj post.</h4>
<?php endif; ?>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/posts/show.blade.php ENDPATH**/ ?>