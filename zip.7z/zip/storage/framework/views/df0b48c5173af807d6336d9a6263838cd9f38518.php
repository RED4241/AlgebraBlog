<?php if(session()->has('flash_message')): ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session()->get('flash_message')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/layouts/messages.blade.php ENDPATH**/ ?>