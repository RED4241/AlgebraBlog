<div class="blog-header">
    <div class="container">
        <h1 class="blog-title"><?php echo e(config('app.name')); ?></h1>
        <p class="lead blog-description">An example blog template built with Bootstrap.</p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/layouts/header.blade.php ENDPATH**/ ?>