<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Uredite POST</div>

        <div class="card-body">

            <form method="POST" action="<?php echo e(route('posts.update', $post->slug)); ?>">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
               

                <div class="form-group row">
                    <label for="title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Title')); ?></label>

                    <div class="col-md-6">
                        <input id="title" type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" value="<?php echo e($post->title); ?>" autofocus>
                        
                        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="body" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Body')); ?></label>

                    <div class="col-md-6">
                        <textarea id="body" type="body" class="form-control <?php if ($errors->has('body')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('body'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="body" value="" rows="6"><?php echo e($post->body); ?></textarea>

                        <?php if ($errors->has('body')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('body'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>

                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="btn btn-primary">Natrag</a>
                        <button type="submit" class="btn btn-success float-right">Uredi</button>
                    </div>
                </div>
                <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\filip_poljak\napredni_php\AlgebraBlog\resources\views/posts/edit.blade.php ENDPATH**/ ?>