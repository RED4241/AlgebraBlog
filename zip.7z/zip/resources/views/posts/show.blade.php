@extends('layouts.master')

@section('content')

<div class="blog-post">

    <h2 class="blog-post-title">
        {{ $post->title }}
    </h2>

    <p class="blog-post-meta">
        <!-- https://carbon.nesbot.com/docs/#api-formatting -->
        {{ $post->created_at->toFormattedDateString() }} by<a href="#">{{ $post->user->name }}</a>
    </p>
    
    <article class="text-justify">
        {{ $post->body }}
    </article>

</div>

<form action="{{ route('posts.destroy', $post->id)  }}" method="post">
        @method('DELETE')
        @csrf 

        @if($post->user_id === auth()->id())
        <div class="float-right">
            <a href="{{ route('posts.edit', $post->slug) }}" class="btn btn-info">Uredi</a>
            <button class="btn btn-danger">Obriši</button>
         </div>
         @endif

<a href="{{  route('posts.index') }}" class="btn btn-primary">Natrag</a>
</form>

<br>

<div class="card">
    <div class="card-body">
        <form action="posts/{{ $post->slug }}/comments" method="post">
            @csrf
            <div class="form-group">
                <textarea name="body" id="body" cols="30" rows="3" class="form-control {{ $errors->has('body') ? 'is-invalid' : '' }}"></textarea>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Komentiraj</button>
            </div>
        </form>    
    </div>
</div>
@if(count($post->comments))
<br>

<div class="comments">
    <h4>Komentari:</h4>
    <ul class="list-group">
    @foreach ($post->comments as $comment)
        <li class="list-group-item">
            <b>Ime Prezime</b>
            <i>19.07.2019.</i>
            <p>Ovo je tijelo komentara.</p>
        </li>
        <li class="list-group-item">
            <b>{{ $comment->user->name }}</b>
            <i>{{ $comment->created_at->diffForHumans }}</i>
            <p>{{ $comment->body }}</p>
        </li>
        @endforeach
    </ul>
</div>
@else
<br>
<h4>Budi prvi koji će komentirati ovaj post.</h4>
@endif
<br>
@endsection